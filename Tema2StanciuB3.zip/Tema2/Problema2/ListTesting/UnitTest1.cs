using ClassLibrary3;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace ListTesting
{
    [TestClass]
    public class UnitTest1
    {
        ProductRepository sut;
        [TestInitialize]
        public void TestInitialize()
        {
            sut = new ClassLibrary3.ProductRepository();
        }
        [TestCleanup]
        public void TestCleanup()
        {
            sut = null;
        }

        [TestMethod]
        public void When_FirstPossitionOfList_ThenShould_ReturnBanana()
        {
            // Arrange && Act
            var elementByPosition = sut.GetProductByPosition(0);
            //Assert
            Assert.IsTrue(string.Equals(elementByPosition.Name, "Banana"));
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void When_PositionIsNegative_Then_Exception()
        {
            var elementByPosition = sut.GetProductByPosition(-1);
        }
        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void When_PositionIsTooBig_Then_Exception()
        {
            var elementByPosition = sut.GetProductByPosition(4);
        }
        [TestMethod]
        public void When_RemoveElementByName_Then_LenghtLowers()
        {
            // Arrange && Act
            sut.RemoveProductByName("Banana");
           
            //Assert
            Assert.IsFalse(string.Equals(sut.GetProductByPosition(0).Name, "Banana"));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void When_ProductDoesntExist_Then_Exception()
        {
            sut.RemoveProductByName("Alabala");
        }




    }
}
