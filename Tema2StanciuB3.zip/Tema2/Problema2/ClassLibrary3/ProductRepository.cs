﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary3
{
    public class ProductRepository
    {
        private List<Product> ProductList;
        public ProductRepository()
        {
            ProductList = new List<Product>()
            {
            new Product(1,"Banana","Galbena",new DateTime(2013,1,23),new DateTime(2014,2,12),20,19),
            new Product(2, "Portocala", "Dulce", new DateTime(2012, 1, 23), new DateTime(2014, 2, 12), 212, 19),
            new Product(2, "Ciocolata", "Neagra", new DateTime(2014, 1, 23), new DateTime(2014, 2, 12), 230, 19)
            };
        }
     

        public Product GetProduct(string name)
        {
            foreach(var product in ProductList)
            {

                if (string.Equals(product.Name, name))
                {
                    return product;
                }
            }
            throw new System.ArgumentException("Nu exista in lista");
        }
        public void AddProduct(Product p)
        {
            ProductList.Add(p);
        }

        public Product GetProductByPosition(int position)
        {
            int currentpos = -1;
            if (position < 0)
                throw new System.IndexOutOfRangeException("Pozitia trebuie sa fie >=0");
            foreach(var product in ProductList )
            {
                currentpos++;
                if (currentpos == position)
                {
                    return product;
                }
            }
            throw new System.IndexOutOfRangeException("Lista nu contine aceasta pozitie");
        }

        public int RemoveProductByName(string productName)
        {
            int position = -1;
            foreach(var product in ProductList)
            {
                position++;
                if (string.Equals(product.Name, productName))
                {
                    ProductList.RemoveAt(position);
                    return 0;
                }
            }
            throw new System.ArgumentException("Nu exista acest produs");
        }
    }
}
