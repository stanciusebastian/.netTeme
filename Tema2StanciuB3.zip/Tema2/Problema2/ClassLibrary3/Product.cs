﻿using System;

namespace ClassLibrary3
{
    public class Product
    {
        private int Id;
        public string Name;
        private string Description;
        private DateTime StartDate;
        private DateTime EndDate;
        private double Price;
        private double VAT;
        public Product(int id, string name, string description, DateTime startDate, DateTime endDate, double price, double vAT)
        {
            Id = id;
            Name = name;
            Description = description;
            StartDate = startDate;
            EndDate = endDate;
            Price = price;
            VAT = vAT;
        }

        public bool IsValid()
        {
            if (Math.Abs(StartDate.Month - EndDate.Month) > 12)
                return false;
            return true;
        }
        public double ComputeVat()
        {
            return Price + (1.9 * Price);
        }

        public override string ToString()
        {
            return this.Name;
        }
    }
}
