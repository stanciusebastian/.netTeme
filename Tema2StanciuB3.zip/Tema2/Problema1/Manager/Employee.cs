﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Manager
{
    class Employee
    {
        private string FirstName;
        private string LastName;
        private DateTime StartDate;
        private DateTime EndDate;
        private double Salary;

    }
}
