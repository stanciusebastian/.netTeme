﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Manager
{
    public class Architect : Employee 
    {
        public Architect()
        {
            this.FirstName = "Keylor";
            this.LastName = "Navasinco";
            StartDate = new DateTime(2015, 12, 25);
            EndDate = new DateTime(2018, 10, 23);
            this.Salary = 3203.9;
        }
        public string GetFullName()
        {
            return FirstName + LastName;
        }

        public bool IsActive()
        {
            return EndDate.Subtract(System.DateTime.Now).Seconds >= 0;
        }

        public string Salutation()
        {
            return "Hello Architect";
        }
    }
}
