﻿using System;

namespace Manager
{
    public class Manager : Employee
    {
        public Manager()
        {
            this.FirstName = "Alex";
            this.LastName = "Opr";
            StartDate = new DateTime(2015, 12, 25);
            EndDate = new DateTime(2018, 10, 23);
            this.Salary = 3503.9;
  
        }

        public Manager(string firstName, string lastName, DateTime startDate, DateTime endDate, double salary)
        {
            FirstName = firstName;
            LastName = lastName;
            StartDate = startDate;
            EndDate = endDate;
            Salary = salary;
        }

        public string GetFullName()
        {
            return FirstName + LastName;
        }

        public bool IsActive()
        {
            return EndDate.Subtract(System.DateTime.Now).Seconds >= 0;
        }

        public string Salutation()
        {
            return "Hello manager";
        }
    }
}
