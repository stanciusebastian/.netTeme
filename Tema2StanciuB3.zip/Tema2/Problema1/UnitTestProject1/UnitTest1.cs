using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]

        public void When_ManagerFullNameIsCalled_ThenShould_FN()
        {
            //Arrange
            var manager = new Manager.Manager();
            //Act
            var result = manager.GetFullName();
            //Assert
            Assert.IsTrue(result.Equals("AlexOpr"));
        }

        [TestMethod]
        public void When_ArhitectFullNameIsCalled_ThenShould_FN()
        {
            //Arrange
            var architect = new Manager.Architect();
            //Act
            var result = architect.GetFullName();
            //Assert
            Assert.IsTrue(result.Equals("KeylorNavasinco"));
        }

        [TestMethod]
        public void When_ManagerIsActive_ThenShould_BeActive()
        {
            //Arrange
            var manager = new Manager.Manager();
            //Act
            var result = manager.IsActive();
            //Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void When_ArchitectIsActive_ThenShould_BeActive()
        {
            //Arrange
            var architect = new Manager.Architect();
            //Act
            var result = architect.IsActive();
            //Assert
            Assert.IsTrue(result);
        }


        [TestMethod]
        public void When_ManagerSalutare_ThenShould_BeHelloManager()
        {
            //Arrange
            var manager = new Manager.Manager();
            //Act
            var result = manager.Salutation();
            //Assert
            Assert.IsTrue(result.Equals("Hello manager"));
        }

        [TestMethod]
        public void When_ArchitectSalutare_ThenShould_BeHelloArchitect()
        {
            //Arrange
            var architect= new Manager.Architect();
            //Act
            var result = architect.Salutation();
            //Assert
            Assert.IsTrue(result.Equals("Hello Architect"));
        }


    }
}
